
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.animation import MovieWriter
import numpy as np



input = open('fort.42')

#n_points = 4800
#
#long_x = []
#
#
#x_str = input.readlines()
#
#len_x = len(x_str)/n_points
#
#print(len_x)
#
#j=0
#while j < len(x_str):
#	x = x_str[j]
#	x = x.replace('\n', '')	
#	x = x.replace('D', 'e')
#	x_val = x
#
#	try:
#		long_x.append(float(x_val))		
#	
#	except:
#		print(j, x_val)
#	j=j+1
#
#long_x = np.array(long_x)
#long_x.shape=(int(len_x),n_points)
#
#
#inx = np.arange(0,n_points,1)
#
#xmax = np.max(abs(long_x))

im = []
fig = plt.figure(1, figsize = (6,6))

i=0
while i <970:
    nroot = input.readline()
    nroot = int(nroot)
    nroot = nroot/2
    nroot = int(nroot)
    print(nroot)
    long_pts = []
    j=0
    while j < (2*nroot):
#        print(j)
        x = input.readline()
        x = x.replace('\n', '')	
        x = x.replace('D', 'e')
        x_val = x
        
        try:
        	long_pts.append(float(x_val))		
        
        except:
        	print(j, x_val)
        j=j+1
    long_pts = np.array(long_pts)    
    amat = long_pts.reshape(nroot,2)    
    xvals= amat[:,0]
    yvals= amat[:,1]
    ax1 = fig.add_subplot(111)		
    ax1.set_xlim(-3.1,3.1)
    im_for_arr = ax1.scatter(xvals, yvals, marker='o', c='k', s=10)
#    plt.scatter(xvals,yvals,marker='o',c='k',s=20)
#    plt.show()
#    im_for_arr.show()
#    im.append(
#    exit()
    	
    #ax1.set_xlim(-1,1)
    #ax1.set_ylim(-1.1*xmax,xmax*1.1)	
    	
    	# again, just axes labels, these can be changed 
    #ax1.set_xlabel(r'$\theta$', fontsize=14)
    #ax1.set_ylabel(r'$\phi$', fontsize=14)	
    	
    im.append([im_for_arr])		
    
    i=i+1
print(len(im))
anim = animation.ArtistAnimation(fig, im, interval=200, blit=False)	
anim.save('J_movie.mp4')



